import Triangle as tamgiac
tg1 = tamgiac.Triangle(3,2,5,7)
tg1.display()

tg2 = tamgiac.Triangle(6,8,9,10)
tg2.display()