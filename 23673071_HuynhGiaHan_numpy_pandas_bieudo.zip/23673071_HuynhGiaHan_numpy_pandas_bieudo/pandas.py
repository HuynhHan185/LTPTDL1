import pandas as pd
# Tạo Series
s = pd.Series([10, 20, 30, 40], index=['a','b','c','d'])
print(s)
# Tạo DataFrame từ dictionary
data = { 'Name': ['An', 'Bình', 'Chi'],
'Age': [20, 21, 19],
'Score': [85, 90, 88]}
df = pd.DataFrame(data)
print(df)

import pandas as pd
# Tạo DataFrame
data = {'Tên': ['An', 'Bình', 'Chi'],
'Tuổi': [23, 25, 22],
'Điểm': [8.5, 9.0, 7.8]}
df = pd.DataFrame(data)
# Xem dữ liệu
print(df)
# Tính điểm trung bình
print(df['Điểm'].mean())

#Tạo Series:
#Ví dụ 1: Không truyền index
import pandas as pd
s = pd.Series([0,1,2,3])
print(s)

#Ví dụ 2: Có truyền index
import pandas as pd
s = pd.Series([0,1,2,3], index=["a","b","c","d"])
print(s)

#Ví dụ 3: Tạo Series từ dict
import pandas as pd
data = {'a' : -1.3, 'b' : 11.7, 'd' : 2.0, 'f': 10, 'g': 5}
ser = pd.Series(data,index=['a','c','b','d','e','f'])
print(ser)

#Ví dụ 4: Tạo Series từ Scalar Nếu dữ liệu là một giá trị scalar, index phải được
#cung cấp. Giá trị sẽ được lặp lại để phù hợp với độ dài của index.
import pandas as pd
ser = pd.Series(5, index=[1, 2, 3, 4, 5])
print(ser)

#Tạo dữ liệu Series 5:
import pandas as pd
import numpy as np
S = pd.Series(np.random.randint(100, size = 4))
print(S)
print(S.index)
print(S.values)

#Tạo dữ liệu Series 6:
import pandas as pd
import numpy as np
chi_so = ["Ke toan", "KT", "CNTT", "Co khi"]
gia_tri = [310, 360, 580, 340]
S = pd.Series(gia_tri, index=chi_so)
print(S)
print(S.index)
print(S.values)

#Tạo dữ liệu Series 7:
import pandas as pd
import numpy as np
chi_so = ["KT", "KT", "CNTT", "Co khi"] # trùng nhau
gia_tri = [310, 360, 580, 340]
S = pd.Series(gia_tri, index=chi_so)
print(S)
print(S.index)
print(S.values)

#Ví dụ 1: Lấy dữ liệu tại index cụ thể.
import pandas as pd
data = {'a' : -1.3, 'b' : 11.7, 'd' : 2.0, 'f': 10, 'g': 5}
ser = pd.Series(data,index=['a','c','b','d','e','f'])
print(ser['d'])
print(ser['c'])
print(ser)

#Ví dụ 2: Lấy dữ liệu từ đầu đến vị trí index cụ thể
import pandas as pd
data = {'a' : -1.3, 'b' : 11.7, 'd' : 2.0, 'f': 10, 'g': 5}
ser = pd.Series(data,index=['a','c','b','d','e','f'])
print(ser[:'d'])

#Ví dụ 3: Lấy dữ liệu theo vị trí: 2 dữ liệu đầu
import pandas as pd
data = {'a' : -1.3, 'b' : 11.7, 'd' : 2.0, 'f': 10, 'g': 5}
ser = pd.Series(data,index=['a','c','b','d','e','f'])
print(ser[:2])

#Ví dụ 4: Lấy 3 dữ liệu cuối
import pandas as pd
data = {'a' : -1.3, 'b' : 11.7, 'd' : 2.0, 'f': 10, 'g': 5}
ser = pd.Series(data,index=['a','c','b','d','e','f'])
print(ser[-3:])

#Ví dụ 5: Lấy dạng array của Series bằng numpy.asarray
import pandas as pd
data = {'a' : -1.3, 'b' : 11.7, 'd' : 2.0, 'f': 10, 'g': 5}
ser = pd.Series(data,index=['a','c','b','d','e','f'])
a = np.asarray(ser)
print(a)

#Truy xuất dữ liệu thông qua chỉ số:
import pandas as pd
import numpy as np
chi_so = ["KT", "KT", "CNTT", "Co khi"] # trùng nhau
gia_tri = [310, 360, 580, 340]
S = pd.Series(gia_tri, index=chi_so)
print(S['Co khi'])
print(S['KT'])
print(S.CNTT)

#Phép toán trên Series:
import pandas as pd
import numpy as np
chi_so = ["Ke toan", "KT", "CNTT", "Co khi"]
gia_tri = [310, 360, 580, 340]
# chỉ số giống nhau thì tính gộp, nếu không thì NaN
S = pd.Series(gia_tri, index=chi_so)
P = pd.Series([100, 100], ['CNTT', 'PM'])
Y = S + P
print(Y)

#Hàm Apply():
import pandas as pd
import numpy as np
def Tang(x):
    return x if x > 500 else x + 1000
chi_so = ["Ke toan", "KT", "CNTT", "Co khi"]
gia_tri = [310, 360, 580, 340]
S = pd.Series(gia_tri, chi_so)
# áp dụng Tang trên S (không thay đổi S)
print(S.apply(Tang))

#Tạo DataFrame từ dict các Series 1:
import pandas as pd
# tạo dict từ các series
s = {'một': pd.Series([1., 2., 3., 5.], index=['a', 'b', 'c', 'e']),
'hai': pd.Series([1., 2., 3., 4.], index=['a', 'b', 'c', 'd'])}
# tại DataFrame từ dict
df = pd.DataFrame(s)
print(df)

#Tạo DataFrame từ dict các Series 2:
import pandas as pd
# tạo dict từ các series
s = {'một': pd.Series([1., 2., 3., 5.], index=['a', 'b', 'c', 'e']),
'hai': pd.Series([1., 2., 3., 4.], index=['a', 'b', 'c', 'd'])}
# tạo DataFrame từ dict theo các index được chọn
df = pd.DataFrame(s, index=['a','c','d'])
print(df)

#Tạo dataframe tử list:
import pandas as pd
names = ['MIT',"Stanford","DHTL"]
df = pd.DataFrame(names)
print(df)
names_rank=[['MIT',1],["Stanford",2],["DHTL",200]]
df = pd.DataFrame(names_rank)
print(df)

#Tạo dataframe tử dictionary các list:
crimes_rates = {
"Year":[1960,1961,1962,1963,1964],
"Population":[179323175,182992000,185771000,188483000,191141000],
"Total":[3384200,3488000,3752200,4109500,4564600],
"Violent":[288460,289390,301510,316970,364220] }
crimes_dataframe = pd.DataFrame(crimes_rates)
print(crimes_dataframe)

#Tạo dataframe tử list các dictionary:
data = [ {'MIT': 5000, 'Stanford': 4500, "DHTL":15000},
{'MIT': 1, 'Stanford': 2, "DHTL":200} ]
df = pd.DataFrame(data, index=['NumOfStudents', "ranking"])
print(df)
print(df.DHTL.dtype)

#Tạo dataframe tử dictionary series:
data = { "one": pd.Series([1,23,45], index = [1,2,3]),
"two": pd.Series([1000,2400,1132,3434], index = [1,2,3,4]) }
df = pd.DataFrame(data)
print(df)

#Ví dụ 3: Chọn cột (column selection)
import pandas as pd
s = {'một': pd.Series([1., 2., 3., 5.], index=['a', 'b', 'c', 'e']),
'hai': pd.Series([1., 2., 3., 4.], index=['a', 'b', 'c', 'd']),
'ba': pd.Series([9., -1.3, 3.5, 41.1], index=['a', 'b', 'c', 'd'])}
df = pd.DataFrame(s)
# chọn cột hai
df_hai = df['hai']
print(df_hai)

#Ví dụ 4: Một số cách thêm cột (column addition)
import pandas as pd
s = {'một': pd.Series([1., 2., 3., 5.], index=['a', 'b', 'c', 'e']),
'hai': pd.Series([1., 2., 3., 4.], index=['a', 'b', 'c', 'd']),
'ba': pd.Series([9., -1.3, 3.5, 41.1], index=['a', 'b', 'c', 'd'])}
df = pd.DataFrame(s)
# thêm cột bốn với giá trị mỗi ô theo công thức
df_bon = df['hai'] - df['ba']
print(df_bon)

#Các thao tác chọn, thêm, xóa cột
# thêm cột với giá trị vô hướng (scalar value)
df['Chuẩn'] = 'OK'
# thêm cột không cùng số lượng index với DataFrame
df['Khác'] = df['hai'][:3]
# thêm cột True/False theo điều kiện
df['KT'] = df['một'] == 3.0
# dùng hàm insert. Cột "chèn" bên dưới sẽ ở vị trí 2 (tính từ 0), có giá trị bằng cột một
df.insert(2, 'chèn', df['một'])
print(df)

#Ví dụ 5: Xóa cột (column deletion). Có thể xóa cột bằng lệnh def hoặc hàm pop
import pandas as pd
s = {'một': pd.Series([1., 2., 3., 5.], index=['a', 'b', 'c', 'e']),
'hai': pd.Series([1., 2., 3., 4.], index=['a', 'b', 'c', 'd']),
'ba': pd.Series([9., -1.3, 3.5, 41.1], index=['a', 'b', 'c', 'd'])}
df = pd.DataFrame(s)
# xóa cột hai
del df['hai']
# pop cột ba với dict tv_ba
tv_ba = df.pop('ba')
print( df)

#Ví dụ 2: Chọn dòng theo vị trí nguyên
import pandas as pd
s = {'một': pd.Series([1., 2., 3., 5.], index=['a', 'b', 'c', 'e']),
'hai': pd.Series([1., 2., 3., 4.], index=['a', 'b', 'c', 'd']),
'ba': pd.Series([9., -1.3, 3.5, 41.1], index=['a', 'b', 'c', 'd'])}
df = pd.DataFrame(s)
# chọn dòng theo vị trí nguyên
d = df.iloc[4]
print(d)

#Ví dụ 3: Cắt (slice) các dòng
import pandas as pd
s = {'một': pd.Series([1., 2., 3., 5.], index=['a', 'b', 'c', 'e']),
'hai': pd.Series([1., 2., 3., 4.], index=['a', 'b', 'c', 'd']),
'ba': pd.Series([9., -1.3, 3.5, 41.1], index=['a', 'b', 'c', 'd'])}
df = pd.DataFrame(s)
# cắt lấy ra từ dòng 3 đến dòng 4
d = df[2:4]
print(d)

#Ví dụ đọc và ghi file
df = pd.read_csv("data.csv") # đọc file CSV
df.to_csv("output.csv", index=False) # ghi file CSV
df = pd.read_excel("data.xlsx") # đọc file Excel
df.to_excel("output.xlsx", index=False)

#Nội dung của file brics.csv:
import pandas as pd
# đọc dữ liệu và quy định cột 0 dùng làm chỉ số dòng
d = pd.read_csv("brics.csv", index_col = 0)
print(d)

# tạo ra dataframe mới bằng cách xóa 2 cột
print(d.drop(["area", "population"], axis=1))
# trường hợp muốn xóa trên d, thêm tham số inplace=True
d.drop(["area", "population"], axis=1, inplace=True)
print(d)

# tính tổng của cột population, trả về tổng
print(d.population.sum())
# tính tổng của cột population, trả về các tổng trong quá trình cộng
print(d.population.cumsum())#

#xem luot qua ve du lieu
import pandas as pd
import matplotlib.pyplot as plt
d = pd.read_csv("brics.csv", index_col = 0)
d.describe()

#ket hop giua pandas va matplotib
import pandas as pd
import matplotlib.pyplot as plt
d = pd.read_csv("brics.csv", index_col = 0)
d.area.plot(kind='bar')
plt.show()