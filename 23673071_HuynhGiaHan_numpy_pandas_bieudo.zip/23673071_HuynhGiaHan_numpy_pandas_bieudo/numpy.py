import numpy as np
a = np.array([1, 2, 3, 4, 5])
b = np.array([[1, 2, 3], [4, 5, 6]])
zeros = np.zeros((2, 3))
ones = np.ones((3,3))
rand = np.random.rand(2, 3)
arange = np.arange(0, 10, 2) # [0,2,4,6,8]
linspace = np.linspace(0, 1, 5) # 5 số cách đều từ 0 đến 1

#thuoc tinh manr
print(a.shape) # kích thước (số dòng, số cột)
print(a.ndim) # số chiều
print(a.size) # tổng số phần tử
print(a.dtype)

#truy cap va cat mang
x = np.array([10, 20, 30, 40, 50])
print(x[0]) # 10
print(x[-1]) # 50
print(x[1:4]) # [20 30 40]
print(x[:3])

#cac phep so sanh
a = np.array([1, 2, 3])
b = np.array([4, 5, 6])
print(a + b) # [5 7 9]
print(a - b) # [-3 -3 -3]
print(a * b) # [4 10 18]
print(a / b) # [0.25 0.4 0.5]
print(a ** 2) # [1 4 9]
print(np.dot(a, b)) # Tích vô hướng = 32

#Hàm toán học
arr = np.array([1, 2, 3, 4, 5])
print(np.sum(arr)) # 15
print(np.mean(arr)) # 3.0 (trung bình)
print(np.max(arr)) # 5
print(np.min(arr)) # 1
print(np.std(arr))

#Ma trận và đại số tuyến tính
A = np.array([[1, 2], [3, 4]])
B = np.array([[2, 0], [1, 3]])
print(np.matmul(A, B)) # nhân ma trận
print(np.linalg.inv(A)) # ma trận nghịch đảo
print(np.linalg.det(A)) # định thức

